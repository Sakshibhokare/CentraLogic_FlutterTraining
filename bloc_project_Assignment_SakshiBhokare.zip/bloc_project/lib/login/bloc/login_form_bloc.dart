import 'dart:async';

import 'package:flutter_form_bloc/flutter_form_bloc.dart';

class LogInFormBloc extends FormBloc<String, String>{

  final email =TextFieldBloc(
      validators: [FieldBlocValidators.email, FieldBlocValidators.required]);

  final password =TextFieldBloc(validators: [FieldBlocValidators.required]);

  final booleanField= BooleanFieldBloc();

  LogInFormBloc(){
    addFieldBlocs(fieldBlocs: [
      email,
      password,
      booleanField
    ]);
  }


  @override
  FutureOr<void> onSubmitting(){

    Future.delayed(const Duration(seconds: 1));
    if(booleanField.value){
      emitSuccess();
    }
    else{
      emitFailure();
    }
  }
}